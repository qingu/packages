.TH Dashsupr 3NCARG "March 1993" UNIX "NCAR GRAPHICS"
.na
.nh
.SH NAME
Dashsupr - The dash utilities have all been incorporated into the
Dashline utility.  To see its man page, type "man dashline".
