C
C	$Id: fnterr.h,v 1.4 2008-07-27 12:23:42 haley Exp $
C                                                                      
C			     Copyright (C)  1997
C	     University Corporation for Atmospheric Research
C			     All Rights Reserved
C
C The use of this Software is governed by a License Agreement.
C

      COMMON /FNTERR/ ALLOK, EOFFL, INTERR, MAXINT
      INTEGER         ALLOK, EOFFL, INTERR, MAXINT
