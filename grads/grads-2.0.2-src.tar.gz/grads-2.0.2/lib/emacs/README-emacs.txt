Emacs modes for GrADS:

To enable, add the following lines to the .emacs file in your home directory:

(require 'gs-mode "<your_grads_home>/lib/emacs/gs-mode.el")
(require 'ctl-mode "<your_grads_home>/lib/emacs/ctl-mode.el")

