/*  If map data sets change, these constants also change */

static int hcntt[4] = {57995,13355,57661,21047};
static int hcntg[4] = {51553,10937,44497,18415};
static int hpos[4] = {0, 231980, 285400, 516040};
static int mcntt[4] = {8591,2135,8553,3199};
static int mcntg[4] = {7400,1771,6390,2767};
static int mpos[4] = {0, 34364, 42904, 77116};
static int lcntt[4] = {2895,872,3021,1573};
static int lpos[4] = {0,11580,15068,27152};

